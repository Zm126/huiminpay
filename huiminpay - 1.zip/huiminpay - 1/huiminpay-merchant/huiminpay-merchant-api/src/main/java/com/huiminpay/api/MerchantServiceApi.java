package com.huiminpay.api;

import com.huiminpay.dto.MerchantDTO;


public interface MerchantServiceApi {

    /**
     * 根据id查询merchant信息
     * @param id
     * @return
     */
    public MerchantDTO queryMerchantById(Long id);

    /**
     * 商户注册
     * @param merchantDTO
     * @return
     */
    public MerchantDTO registerMerchant(MerchantDTO merchantDTO);

    /**
     * 资质申请接口
     * @param merchantId 商户id
     * @param merchantDTO 资质申请的信息
     */
    public void applyMerchant(Long merchantId,MerchantDTO merchantDTO);

}
