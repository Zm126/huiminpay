package com.huiminpay.api;

/**
 * 文件上传到阿里云
 */
public interface FileService {
    public String upload(byte[] bytes,String fileName);
}
