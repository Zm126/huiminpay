package com.huiminpay.test;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.huiminpay.bean.User;
import com.huiminpay.mapper.UserMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import static com.baomidou.mybatisplus.core.enums.SqlKeyword.AND;
import static com.baomidou.mybatisplus.core.enums.SqlKeyword.IN;

@SpringBootTest
@RunWith(SpringRunner.class)
public class MybatisTest {
    @Resource
    private UserMapper userMapper;

    /**
     * 基础测试
     */
    @Test
    public void testSelect(){
        List<User> users = userMapper.selectList(null);
        for (User user : users) {
            System.out.println(user);
        }
    }

    @Test
    public void testInsert(){
        User user = new User();
        user.setAge(20);
        user.setEmail("test@yunhe.cn");
        user.setUserName("曹操");
        user.setName("曹操");
        user.setPassword("123456");
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy‐MM‐dd   HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse("1990‐01‐01   00:00:00", df);
        user.setBirthday(localDateTime);
        int insert = userMapper.insert(user);
        System.out.println("影响的行数："+insert);
        //自增后的id回填到对象中
        System.out.println(user.getId());
    }

    /**
     * 更新单条数据user
     */
    @Test
    public void testUpdateById(){
        User user = new User();
        user.setId(7L);
        user.setAge(21);
        user.setName("赵云");
        user.setUserName("赵云");
        userMapper.updateById(user);
    }

    /**
     * 批量更新
     */
    @Test
    public void testUpdate(){
        User user = new User();
        user.setAge(22);
        //更新操作
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("name","赵云");
        //执行更新操作
        int i = userMapper.update(user,wrapper);
        System.out.println("更新后的结果："+i);
    }

    /**
     * 根据id删除user
     */
    @Test
    public void testDeleteById(){
        int i = userMapper.deleteById(7L);
        System.out.println("更新后的结果："+i);
    }

    /**
     * 根据条件删除
     */
    @Test
    public void testDeleteByMap(){
      /*  User user = new User();
        user.setAge(20);
        user.setName("张三");*/
        //将实体类对象进行包装，包装为操作条件
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("age",20);
        wrapper.eq("name","张三");
        int delete = userMapper.delete(wrapper);
        System.out.println("删除后的结果："+delete);
    }

    /**
     * 根据id批量删除user
     */
    @Test
    public void testDeleteByIds(){
        int i = userMapper.deleteBatchIds(Arrays.asList(10L, 20L, 30L));
        System.out.println("结果为："+i);
    }

    //查询操作

    /**
     * 根据id查询
     */
    @Test
    public void testSelectById(){
        User user = userMapper.selectById(2L);
        System.out.println("result:"+user);
    }

    /**
     * 根据id列表查询
     */
    @Test
    public void testSelectBatchIds(){
        List<User> users = userMapper.selectBatchIds(Arrays.asList(1L, 2L, 3L));
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 根据对象查询
     */
    @Test
    public void testSelectOne(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("name","张三");

        User user = userMapper.selectOne(wrapper);
        System.out.println("result:"+user);
    }

    /**
     * 查询总记录数
     */
    @Test
    public void testSelectCount(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        //年龄大于22的数
        wrapper.gt("age", 22);

        Integer count = userMapper.selectCount(wrapper);
        System.out.println("result:"+count);
    }

    /**
     * 根据entity条件，查询全部记录
     */
    @Test
    public void testSelectList(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.gt("age",20);

        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 分页查询
     */
    @Test
    public void testSelectPage(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.gt("age",18);
        //1，当前页码
        //2，每页记录数
        Page<User> page = new Page<>(1, 2);
        //根据条件查询数据
        IPage<User> userIPage = userMapper.selectPage(page, wrapper);
        System.out.println("数据总数条数："+userIPage.getTotal());
        System.out.println("总页数："+userIPage.getPages());
        //取出分页记录
        List<User> users = userIPage.getRecords();
        for (User user : users) {
            System.out.println(user);
        }
    }

    //条件构造器

    /**
     * 多条件查询
     */
    @Test
    public void testEq(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        //where条件密码为123456，年龄小于20，且在"张三","李四","王五"中
        wrapper.eq("password","123456")
                .ge("age",20)
                .in("name","张三","李四","王五");
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 使用Lambda查询
     */
    @Test
    public void testLambdaSelect(){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        //where条件密码为123456，年龄小于20，且在"张三","李四","王五"中
        wrapper.eq(User::getPassword,   "123456")
                .ge(User::getAge,   20)
                .in(User::getName,   "李四",   "王五",   "赵六");
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 模糊查询
     */
    @Test
    public void testWrapper(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.like("name","三");
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }
    @Test
    public void testWrapperLambda(){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.like(User::getName,"王");
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }


    /**
     * 逻辑查询
     */
    @Test
    public void testWrapper1(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        //SELECT id,name,age FROM tb_user WHERE name = ? OR age = ?
        wrapper.eq("name","李四")
                .or()
                .eq("age",22)
                .select("id","name","age");
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     *
     * 逻辑查询
     *
     */
    @Test
    public void testWrapper1Lambda(){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getName,"李四")
                .or()
                .eq(User::getAge,24)
                .select(User::getId,User::getName,User::getAge);
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    //排序

    /**
     * orderByDesc  and  orderByAsc
     */
    @Test
    public void testWrapper2(){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.orderByDesc("age");
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 排序
     */
    @Test
    public void testWrapper2Lambda(){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.orderByDesc(User::getAge);
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }

    /**
     * 结合streamapi及lambda表达式对已查询出的结果进行过滤（条件age>20的）
     */
    @Test
    public void testLambda(){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.gt(User::getAge,20);
        List<User> users = userMapper.selectList(wrapper);
        for (User user : users) {
            System.out.println(user);
        }
    }
}
