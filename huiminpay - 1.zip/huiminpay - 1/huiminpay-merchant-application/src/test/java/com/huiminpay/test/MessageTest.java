package com.huiminpay.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
public class MessageTest {

    @Test
    public void testGetSmsCode(){
        String url = "http://127.0.0.1:56085/sailing/generate?effectiveTime=60&name=sms";
        String phone = "17737582030";
        //设置请求体
        HashMap<String, Object> map = new HashMap<>();
        map.put("mobile",phone);
        //设置请求头
        HttpHeaders httpHeaders = new HttpHeaders();
        //设置数据格式为json
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        //封装参数
        HttpEntity<HashMap<String, Object>> hashMapHttpEntity = new HttpEntity<>(map, httpHeaders);
        RestTemplate restTemplate = new RestTemplate();
        //通过restTemplate进行远程调用 ResponseEntity<Map>短信接口返回的数据信息封装在map对象中
        ResponseEntity<Map> forEntity = restTemplate.exchange(url, HttpMethod.POST, hashMapHttpEntity, Map.class);
        Map responseMap = forEntity.getBody();
        //取出body中的result数据
        if (responseMap != null || responseMap.get("result") != null) {
            Map resultMap = (Map) responseMap.get("result");
            String value = resultMap.get("key").toString();
            System.out.println(value);
        }

    }


    /**
     * 获取验证码内容
     */
    @Test
    public void testGetCode() {
        String url = "http://127.0.0.1:56085/sailing/generate?effectiveTime=60&name=sms";
        String phone = "13081936214";
        //请求体
        Map<String, Object > body = new HashMap();
        body.put("mobile", phone);
        //请求头
        HttpHeaders httpHeaders = new HttpHeaders();
        //设置数据格式为json
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        //封装请求参数
        HttpEntity entity = new HttpEntity(body, httpHeaders);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Map> forEntity = restTemplate.exchange(url, HttpMethod.POST, entity, Map.class);
        Map responseMap = forEntity.getBody();
        //取出body中的result数据
        if (responseMap != null || responseMap.get("result") != null) {
            Map resultMap = (Map) responseMap.get("result");
            String value = resultMap.get("key").toString();
            System.out.println(value);
        }
    }
}
