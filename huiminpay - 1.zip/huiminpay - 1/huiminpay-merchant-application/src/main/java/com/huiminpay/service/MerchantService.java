package com.huiminpay.service;

import com.huiminpay.api.MerchantServiceApi;
import com.huiminpay.common.cache.domain.CommonErrorCode;
import com.huiminpay.common.cache.exception.BusinessCast;
import com.huiminpay.common.cache.util.PhoneUtil;
import com.huiminpay.convert.MerchantRegisterConvert;
import com.huiminpay.dto.MerchantDTO;
import com.huiminpay.vo.MerchantRegisterVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

@Service
@Slf4j
public class MerchantService {
    @Autowired
    private RestTemplate restTemplate;

    @Reference
    private MerchantServiceApi merchantServiceApi;

    //http://localhost:56085/sailing/
    @Value("${sailing.url}")
    private  String url;

    @Value("${oss.aliyun.accessKeyId}")
    private String accessKeyId;
    @Value("${oss.aliyun.secretKeySecret}")
    private String secretKeySecret;
    @Value("${oss.aliyun.bucket}")
    private String bucket;
    @Value("${oss.aliyun.domain}")
    private String domain;

    /**
     * 商户注册
     * @param merchantRegisterVO
     * @return
     */
    public MerchantRegisterVO register(MerchantRegisterVO merchantRegisterVO){
        //判断传入的参数是否为空
        if (merchantRegisterVO == null){
            BusinessCast.cast(CommonErrorCode.E_100101);
        }
        //判断手机号是否为空
        if (StringUtils.isEmpty(merchantRegisterVO.getMobile())){
            BusinessCast.cast(CommonErrorCode.E_100112);
        }
        //判断手机号格式是否正确
        if (!PhoneUtil.isMatches(merchantRegisterVO.getMobile())){
            BusinessCast.cast(CommonErrorCode.E_100109);
        }
        //判断用户名是否为空
        if (StringUtils.isEmpty(merchantRegisterVO.getUsername())){
            BusinessCast.cast(CommonErrorCode.E_100110);
        }
        //判断密码是否为空
        if (StringUtils.isEmpty(merchantRegisterVO.getPassword())){
            BusinessCast.cast(CommonErrorCode.E_100111);
        }
        //远程调用校验验证码
        this.checkMsmCode(merchantRegisterVO.getVerifyKey(),merchantRegisterVO.getVerifyCode());
        //对象拷贝
        /*MerchantDTO merchantDTO = new MerchantDTO();
        BeanUtils.copyProperties(merchantRegisterVO,merchantDTO);*/
        //使用转换器
        MerchantDTO merchantDTO = MerchantRegisterConvert.INSTANCE.vo2dto(merchantRegisterVO);
        //验证码校验通过，远程调用service添加用户信息
        merchantServiceApi.registerMerchant(merchantDTO);
        return merchantRegisterVO;
    }
    ////远程调用sailing服务校验验证码

    /**
     * 短信验证
     * @param key
     * @param code
     */
    private void checkMsmCode(String key,String code){
        // http://localhost:56085/sailing/verify?name=sms&verificationCode=qq&verificationKey=22
        String msmUrl = url+"verify?name=sms&verificationCode="+code+"&verificationKey="+key;
        try {
            ResponseEntity<Map> responseEntity = restTemplate.exchange(msmUrl,
                    HttpMethod.POST, HttpEntity.EMPTY, Map.class);
            if (responseEntity == null){
                log.error("校验验证码出错");
                BusinessCast.cast(CommonErrorCode.E_100102);
                //throw new RuntimeException("校验验证码出错");
            }
            Map entityBody = responseEntity.getBody();
            if(entityBody == null || entityBody.get("result")==null){
                log.error("校验验证码出错");
                BusinessCast.cast(CommonErrorCode.E_100102);
                //BusinessCast.cast(CommonErrorCode.E_100102);
                //throw new RuntimeException("校验验证码出错");
            }
            boolean result = (boolean)entityBody.get("result");
            if(!result){
                log.error("校验验证码出错");
                BusinessCast.cast(CommonErrorCode.E_100102);
                //throw new RuntimeException("校验验证码出错");
            }
        }catch (Exception e){
            log.error("校验验证码出错:{}",e.getMessage());
            BusinessCast.cast(CommonErrorCode.E_100102);
            //throw new RuntimeException("校验验证码出错");
        }
    }

}
