package com.huiminpay.controller;


import com.aliyun.oss.OSS;
import com.aliyun.oss.model.PutObjectRequest;
import com.huiminpay.api.MerchantServiceApi;
import com.huiminpay.common.cache.domain.CommonErrorCode;
import com.huiminpay.common.cache.exception.BusinessCast;
import com.huiminpay.config.AliyunConfig;
import com.huiminpay.dto.MerchantDTO;
import com.huiminpay.service.MerchantService;
import com.huiminpay.service.SmsService;
import com.huiminpay.vo.MerchantRegisterVO;
import io.swagger.annotations.*;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Api("商户管理系统controller接口，包含商户注册，资质申请，获取验证码等。。。" )
@RestController
@RequestMapping("/merchant")
public class MerchantController {

    @Reference
    private MerchantServiceApi merchantServiceApi;

    @Autowired
    private MerchantService merchantService;

    @Autowired
   private SmsService smsService;

    @Autowired
    private OSS oss;
    @Value("${oss.aliyun.bucket}")
    private String bucket;
    @Value("${oss.aliyun.domain}")
    private String domain;


    @ApiImplicitParam(name = "id" ,value = "商户id",dataType = "Long",required = true)
    @GetMapping("find/{id}")
    public MerchantDTO findMerchantById(@PathVariable("id") Long id){
        return merchantServiceApi.queryMerchantById(id);
    }

    @GetMapping("sms")
    @ApiImplicitParam(name = "mobile" ,value = "手机号",dataType = "String",required = true,paramType="query")
    public String getSendSms(@RequestParam("mobile") String mobile){
        String msmCodeKey = smsService.sendMsmCode(mobile);
        return msmCodeKey;
    }

    @ApiOperation("商户注册")
    @ApiImplicitParam(name = "merchantRegisterVO" ,value = "商户注册信息",dataType = "MerchantRegisterVO",required = true,paramType="body")
    @PostMapping("/merchants/register")
    public MerchantRegisterVO registerMerchant(@RequestBody MerchantRegisterVO merchantRegisterVO){
        MerchantRegisterVO registerVO = merchantService.register(merchantRegisterVO);
        return registerVO;
    }

    @ApiOperation("上传证件照")
    @PostMapping("/upload")
    public String upload(@ApiParam(value = "证件照",required = true) @RequestParam("file") MultipartFile multipartFile){
        String fileName = System.currentTimeMillis()+"";//文件名，当前系统时间戳
        String originalFilename = multipartFile.getOriginalFilename();//上传原文件名
        String ext = originalFilename.substring(originalFilename.indexOf("."));//截取获取扩展名
        try {
            new PutObjectRequest(bucket,fileName+ext,multipartFile.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
            BusinessCast.cast(CommonErrorCode.E_100106);
        }
        return domain+"/"+fileName+ext;
    }

    /*@ApiOperation("资质申请-上传功能")
    @ApiParam(name = "file",value = "文件信息")
    @PostMapping("/upload")
    public String uploadFile(MultipartFile file){
        return merchantService.upload(file);
    }*/

   /* @ApiOperation("资质申请")
    @PostMapping("/my/merchants/save")
    @ApiImplicitParam(name = "merchantDTO" ,value = "商户资质申请信息",dataType = "MerchantDTO",required = true,paramType="body")
    public MerchantDTO applyMerchant(@RequestBody MerchantDTO merchantDTO){
    //  从token获取商户id
        Long merchantId = SecurityUtil.getMerchantId();
        //Long merchantId = 1428246546270515202L;
        MerchantDTO merchantDTODB = merchantServiceApi.applyMerchant(merchantId, merchantDTO);
       //Bearer eyJtZXJjaGFudElkIjoxNDI4NjM5Mzc4MjQ0MTYxNTM4LCJ1c2VyX25hbWUiOiJzdHJpbmciLCJtb2JpbGUiOiIxODUzMDAzNjc0MyJ9

        return merchantDTODB;
    }*/

}
