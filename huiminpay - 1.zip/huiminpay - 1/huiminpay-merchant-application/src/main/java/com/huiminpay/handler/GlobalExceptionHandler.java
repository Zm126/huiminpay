package com.huiminpay.handler;

import com.huiminpay.common.cache.domain.CommonErrorCode;
import com.huiminpay.common.cache.domain.RestErrorResponse;
import com.huiminpay.common.cache.exception.BusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * 全局异常处理类
 */
@ControllerAdvice //该异常对controller切面的增强
public class GlobalExceptionHandler {
    @ExceptionHandler(value = Exception.class) //指定该全局异常处理类的这个方法来处理
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) //服务器异常
    public RestErrorResponse processException(Exception exception){
        //判断异常是否为自定义异常
        if (exception instanceof BusinessException){
            BusinessException businessException = (BusinessException) exception;
            //获取异常信息代码和异常信息描述
            RestErrorResponse response = new RestErrorResponse(businessException.getErrorCode().getCode(), businessException.getErrorCode().getDesc());
            return response;
        }
        //返回未知异常的代码和描述
        return new RestErrorResponse(CommonErrorCode.UNKNOWN.getCode(),CommonErrorCode.UNKNOWN.getDesc());
    }
}
