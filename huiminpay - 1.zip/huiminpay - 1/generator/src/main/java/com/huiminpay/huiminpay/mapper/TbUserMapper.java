package com.huiminpay.huiminpay.mapper;

import com.huiminpay.huiminpay.dto.TbUserDTO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lifly
 * @since 2021-09-06
 */
@Repository
public interface TbUserMapper extends BaseMapper<TbUserDTO> {

}
