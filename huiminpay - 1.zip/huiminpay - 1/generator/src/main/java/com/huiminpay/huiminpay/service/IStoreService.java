package com.huiminpay.huiminpay.service;

import com.huiminpay.huiminpay.dto.StoreDTO;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lifly
 * @since 2021-09-06
 */
public interface IStoreService extends IService<StoreDTO> {

}
