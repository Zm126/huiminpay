package com.huiminpay.convert;


import com.huiminpay.dto.MerchantDTO;
import com.huiminpay.vo.MerchantRegisterVO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MerchantRegisterConvert {

    //创建转换构建器
    MerchantRegisterConvert INSTANCE = Mappers.getMapper(MerchantRegisterConvert.class);

    //将vo转换为dto
    MerchantDTO vo2dto(MerchantRegisterVO vo);

    //将dto转换为vo
    MerchantRegisterVO dto2vo(MerchantDTO dto);
}
