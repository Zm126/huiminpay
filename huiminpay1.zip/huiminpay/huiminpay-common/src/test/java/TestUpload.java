import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import com.aliyun.oss.model.GetObjectRequest;

import java.io.*;

public class TestUpload {
    // yourEndpoint填写Bucket所在地域对应的Endpoint。以华东1（杭州）为例，Endpoint填写为https://oss-cn-hangzhou.aliyuncs.com。
    public static final String ENDPOINT = "oss-cn-beijing.aliyuncs.com";
    public static final String BUCKET = "huiminpay-g";
    public static final String DOMAIN = "http://huiminpay-g.oss-cn-beijing.aliyuncs.com";
    public static final String ACCESSKEY_ID = "LTAI5tRqSy2tviu3aFD1CMbt";
    public static final String ACCESSKEY_SECRET = "2z805h8DHa5Imxjlyyp4pb5Y1L6u0I";
//LTAI5tRqSy2tviu3aFD1CMbt
// 2z805h8DHa5Imxjlyyp4pb5Y1L6u0I
    //七牛云
    //ak  WGeZi55t_42EWtl6AVPGQX-W453aJn7-lffvgZJL
    //sk  N1zHeXKyuzlQ3ULgyC6_jAfGCjlb1CppdRTGR3f6
    public static void main(String[] args) throws IOException {
       //upload();
        download();

    }

    /**
     * 上传
     * @throws FileNotFoundException
     */
    private static void upload() throws FileNotFoundException {
    /*  String endpoint = "oss-cn-beijing.aliyuncs.com";

      String accessKeyId = "LTAI5tHaMFe5wQugBYaTKL7M";
      String accessKeySecret = "TyWCMKKt4dzugkBtHHYp3opr2S83IC";
*/
        /**
         * LTAI5tHaMFe5wQugBYaTKL7M
         * TyWCMKKt4dzugkBtHHYp3opr2S83IC
         */
// 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(ENDPOINT, ACCESSKEY_ID, ACCESSKEY_SECRET);

// 填写本地文件的完整路径。如果未指定本地路径，则默认从示例程序所属项目对应本地路径中上传文件流。
        InputStream inputStream = new FileInputStream("G:\\tu.jpg");

// 依次填写Bucket名称（例如examplebucket）和Object完整路径（例如exampledir/exampleobject.txt）。Object完整路径中不能包含Bucket名称。
        ossClient.putObject(BUCKET,DOMAIN, new File("G:\\tu.jpg"));

// 关闭OSSClient。
        ossClient.shutdown();
    }

    /**
     * 下载
     * @throws IOException
     */
    public static void download() throws IOException {
        // yourEndpoint填写Bucket所在地域对应的Endpoint。以华东1（杭州）为例，Endpoint填写为https://oss-cn-hangzhou.aliyuncs.com。
       // String endpoint = "yourEndpoint";
// 阿里云账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM用户进行API访问或日常运维，请登录RAM控制台创建RAM用户。
       // String accessKeyId = "yourAccessKeyId";
       // String accessKeySecret = "yourAccessKeySecret";
// 填写Bucket名称。
       // String bucketName = "examplebucket";
// 填写Object的完整路径。Object完整路径中不能包含Bucket名称。
        //String objectName = "exampleobject.txt";

// 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(ENDPOINT, ACCESSKEY_ID, ACCESSKEY_SECRET);

// 下载Object到本地文件，并保存到指定的本地路径中。如果指定的本地文件存在会覆盖，不存在则新建。
// 如果未指定本地路径，则下载后的文件默认保存到示例程序所属项目对应本地路径中。
        ossClient.getObject(new GetObjectRequest(BUCKET, DOMAIN), new File("G:\\tu.jpg"));

// 关闭OSSClient。
        ossClient.shutdown();

    }
}
