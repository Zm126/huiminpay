package com.huiminpay.api;

public interface SmsService {
    /**
     * 获取验证码接口
     * @param phone
     * @return
     */
    public String sendSms(String phone);

    /**
     * 验证码校验
     * @param verifyKey 验证码的key,有前端传递
     * @param verifyCode 验证码，由用户输入
     * @return
     */
    public String verifyCode(String verifyKey,String verifyCode);
}
