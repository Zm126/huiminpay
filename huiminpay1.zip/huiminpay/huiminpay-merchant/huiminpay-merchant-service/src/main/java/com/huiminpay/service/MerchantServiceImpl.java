package com.huiminpay.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.huiminpay.api.MerchantServiceApi;
import com.huiminpay.common.cache.domain.CommonErrorCode;
import com.huiminpay.common.cache.exception.BusinessCast;
import com.huiminpay.common.cache.util.PhoneUtil;
import com.huiminpay.convert.MerchantConvert;
import com.huiminpay.dto.MerchantDTO;
import com.huiminpay.entity.Merchant;
import com.huiminpay.mapper.MerchantMapper;
import org.apache.commons.lang.StringUtils;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MerchantServiceImpl implements MerchantServiceApi {
    @Autowired
    private MerchantMapper merchantMapper;


    /**
     * 根据id查询测试
     * @param id
     * @return
     */
    public MerchantDTO queryMerchantById(Long id) {
        Merchant merchant = merchantMapper.selectById(id);
        MerchantDTO merchantDTO = new MerchantDTO();
        //对象拷贝
        BeanUtils.copyProperties(merchant,merchantDTO);
        return merchantDTO;
    }

    /**
     * 商户注册
     * @param merchantDTO
     * @return
     */
    @Override
    @Transactional
    public MerchantDTO registerMerchant(MerchantDTO merchantDTO) {
        //校验必要的参数
        if (merchantDTO != null && StringUtils.isEmpty(merchantDTO.getMobile())){
            throw new RuntimeException("传入的参数异常");
        }
        //判断手机号格式是否正确
        if (!PhoneUtil.isMatches(merchantDTO.getMobile())){
            BusinessCast.cast(CommonErrorCode.E_100109);
        }
        //判断用户名是否为空
        if (StringUtils.isEmpty(merchantDTO.getUsername())){
            BusinessCast.cast(CommonErrorCode.E_100110);
        }

        //手机号唯一性校验
        Integer count = merchantMapper.selectCount(new LambdaQueryWrapper<Merchant>().eq(Merchant::getMobile, merchantDTO.getMobile()));
        if (count>0){
            BusinessCast.cast(CommonErrorCode.E_100113);
        }
        //把dto转换为实体类
      /*  Merchant merchant = new Merchant();
        BeanUtils.copyProperties(merchantDTO,merchant);*/
        //将dto转换为实体类
        Merchant merchant = MerchantConvert.INSTANCE.dto2entity(merchantDTO);
        merchant.setAuditStatus("0");//审核状态0-未审核，1-已申请待审核，2-审核通过，3-审核拒绝
        merchantMapper.insert(merchant);
//        merchantDTO.setId(merchant.getId());
        return MerchantConvert.INSTANCE.entity2dto(merchant);
    }

    /**
     * 资质申请接口
     * @param merchantId 商户id
     * @param merchantDTO 资质申请的信息
     */
    @Override
    public void applyMerchant(Long merchantId, MerchantDTO merchantDTO) {
        //判断merchantId为空或merchantDTO为空
        if (merchantId == null || merchantDTO ==null){
            BusinessCast.cast(CommonErrorCode.E_300009);
        }
        //检验merchantId合法性，查询商户表，如果查询不到记录，认为非法
        Merchant merchant = merchantMapper.selectById(merchantId);
        if (merchant == null){
            BusinessCast.cast(CommonErrorCode.E_200002);
        }
        //将dto转换为entity
        Merchant entity = MerchantConvert.INSTANCE.dto2entity(merchantDTO);
        //将必要的参数设置到entity
        entity.setId(merchant.getId());
        //因为资质申请的时候手机号不让改，还使用数据库中原来的手机号
        entity.setMobile(merchant.getMobile());
        //设置审核状态为1-已申请待审核
        entity.setAuditStatus("1");
        entity.setTenantId(merchant.getTenantId());
        merchantMapper.updateById(entity);
    }


}
