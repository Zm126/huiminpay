package com.huiminpay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huiminpay.bean.User;

public interface UserMapper extends BaseMapper<User> {

}
