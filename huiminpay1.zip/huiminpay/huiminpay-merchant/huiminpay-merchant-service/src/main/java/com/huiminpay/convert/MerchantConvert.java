package com.huiminpay.convert;

import com.huiminpay.dto.MerchantDTO;
import com.huiminpay.entity.Merchant;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface MerchantConvert {

    //创建转换构建器
    MerchantConvert INSTANCE = Mappers.getMapper(MerchantConvert.class);

    public Merchant dto2entity(MerchantDTO merchantDTO);

    public MerchantDTO entity2dto(Merchant merchant);

    public List<MerchantDTO> listEntity2listDto(List<Merchant>merchants);

}
