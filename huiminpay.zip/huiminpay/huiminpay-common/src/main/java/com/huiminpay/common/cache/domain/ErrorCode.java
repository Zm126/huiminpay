package com.huiminpay.common.cache.domain;

public interface ErrorCode {

    int getCode();

    String getDesc();

}
