package com.zhangming.controller;


import com.zhangming.api.IUserService;
import com.zhangming.bean.User;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QueryById {
    
    @Reference
    IUserService iUserService;
    @GetMapping("/iUser/{id}")
    public User iUser(@PathVariable("id") Integer id){
        return iUserService.queryUserById(id);
    }
}
