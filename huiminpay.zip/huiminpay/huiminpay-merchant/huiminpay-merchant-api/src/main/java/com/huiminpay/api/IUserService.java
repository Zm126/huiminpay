package com.huiminpay.api;

import com.huiminpay.bean.User;

public interface IUserService {
    public User queryUserById(Integer id);
}
