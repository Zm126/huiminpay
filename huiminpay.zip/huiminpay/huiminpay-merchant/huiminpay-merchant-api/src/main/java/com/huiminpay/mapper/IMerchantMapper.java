package com.huiminpay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huiminpay.bean.Merchant;

public interface IMerchantMapper extends BaseMapper<Merchant> {
    
    
}
