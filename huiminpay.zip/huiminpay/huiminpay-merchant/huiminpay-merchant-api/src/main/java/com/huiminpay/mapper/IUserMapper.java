package com.huiminpay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.huiminpay.bean.User;

public interface IUserMapper extends BaseMapper<User> {
    public User queryUserById(Integer id) ;
}
