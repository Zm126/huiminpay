package com.huiminpay.api;

public interface ISmsService {
    /**
     * 获取验证码
     * @param phone
     * @return
     */
    public String sendSms(String phone);

    /**
     * 验证码key值
     * @param verifyKey
     * 用户输入验证码
     * @param verifyCode
     * @return
     */
    public String verify(String verifyKey,String verifyCode);
}
