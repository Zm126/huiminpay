package com.huiminpay.bean;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
@ApiModel(description = "商城实体类")
@Data
@TableName("merchant")
public class Merchant implements Serializable {
@ApiModelProperty("主键id")
@TableId("id")
    private Long id;

    @ApiModelProperty("商品名称")
    @TableField("merchant_Name")
    private String merchantName;
    
    @ApiModelProperty("商品编号")
    @TableField("merchant_No")
    private String merchantNo;
    
    @ApiModelProperty("商品地址")
    @TableField("merchant_Address")
    private String merchantAddress;
    
    @ApiModelProperty("商铺类型")
    @TableField("merchant_Type")
    private String merchantType;
    
    @ApiModelProperty("营业执照")
    @TableField("business_Licenses_Img")
    private String businessLicensesImg;
    
    @ApiModelProperty("法人身份证正面")
    @TableField("id_Card_Front_Img")
    private String idCardFrontImg;
    
    @ApiModelProperty("反面")
    @TableField("id_Card_After_Img")
    private String idCardAfterImg;
    
    @ApiModelProperty("负责人名称")
    @TableField("username")
    private String username;
    
    @ApiModelProperty("联系方式")
    @TableField("mobile")
    private String mobile;
    
    @ApiModelProperty("联系人地址")
    @TableField("contacts_Address")
    private String contactsAddress;
    
    @ApiModelProperty("审核状态")
    @TableField("audit_Status")
    private String auditStatus;
    
    @ApiModelProperty("租户id")
    @TableField("tenant_Id")
    private Long tenantId;
}
