package com.huiminpay.service;

import com.huiminpay.api.IUserService;
import com.huiminpay.bean.User;
import com.huiminpay.mapper.IUserMapper;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class UserServiceImpl implements IUserService {
    @Autowired
    IUserMapper iuserMapper;
    
    
    public User queryUserById(Integer id) {
        return iuserMapper.selectById(id);
    }
}
