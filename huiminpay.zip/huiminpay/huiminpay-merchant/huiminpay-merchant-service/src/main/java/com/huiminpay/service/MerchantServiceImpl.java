package com.huiminpay.service;

import com.huiminpay.api.IMerchantService;
import com.huiminpay.api.dto.MerchantDto;
import com.huiminpay.bean.Merchant;
import com.huiminpay.mapper.IMerchantMapper;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
@Service
public class MerchantServiceImpl implements IMerchantService {
    @Autowired
    IMerchantMapper merchantMapper;
    
    public Merchant queryMerchantById(Long id) {
        return merchantMapper.selectById(id);
    }

    @Override
    public MerchantDto createMerchant(MerchantDto merchantDto) {
        Merchant merchant = new Merchant();
        merchant.setAuditStatus("0");
        merchant.setMobile(merchantDto.getMobile());
merchantMapper.insert(merchant);
//回显
        merchantDto.setId(merchant.getId());
        return merchantDto;
    }
}
