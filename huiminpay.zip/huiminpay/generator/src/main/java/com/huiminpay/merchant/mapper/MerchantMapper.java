package com.huiminpay.merchant.mapper;

import com.huiminpay.merchant.dto.MerchantDTO;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 张明
 * @since 2021-09-04
 */
@Repository
public interface MerchantMapper extends BaseMapper<MerchantDTO> {

}
