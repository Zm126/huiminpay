package com.zhangming.api;


import com.zhangming.bean.User;

public interface IUserService {
    public User queryUserById(Integer id);
}
