package com.zhangming.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zhangming.bean.User;

public interface ZhangmingMapper extends BaseMapper<User> {
    public User queryUserById(Integer id) ;
}
