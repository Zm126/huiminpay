package com.zhangming.service;


import com.zhangming.api.IUserService;
import com.zhangming.bean.User;
import com.zhangming.mapper.ZhangmingMapper;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Service
public class UserServiceImpl implements IUserService {
    @Autowired
    ZhangmingMapper zhangmingMapper;
    
    
    public User queryUserById(Integer id) {
        return zhangmingMapper.selectById(id);
    }

    @SpringBootApplication
    public static class ZhangmingService {
    
        public static void main(String[] args) {
            SpringApplication.run(ZhangmingService.class,args);
        }
    }
}
